# Studio Code Insight — Cynbit AI/ML Assessment Prototype

An explainable Python code-review learning aid inspired by Cynbit Studio's public positioning around adaptive coding paths and AI code evaluation.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app/main.py
```

Open the local URL printed by Streamlit (typically http://localhost:8501).

## Run tests

```bash
pip install pytest
pytest -q
```

## Current behavior

- Python syntax parsing using `ast` (no code execution)
- Flags `eval()` and bare `except`
- Highlights print-based diagnostics and long function signatures
- Computes a transparent heuristic rubric for correctness, security, reliability, and maintainability
- Provides strengths, findings, suggested fixes, and next steps

## Important scope boundary

This is a functional proof-of-concept, not a production-grade AI grader. It does not execute code, infer algorithmic correctness, inspect arbitrary project dependencies, use a trained ML model, or call an LLM. The rubric is heuristic and must not be treated as a validated score. The next production step is sandboxed test execution plus an LLM explanation layer constrained by deterministic evidence.

## Architecture

`Streamlit UI -> input validation -> Python AST analyzer -> rubric aggregation -> structured feedback JSON -> UI/download`

See `docs/technical_approach.md` and `docs/opportunity_report.md` for rationale and production plan.
