# Submission execution notes

## Primary deliverable
- `Cynbit_AI_Opportunity_and_Technical_Approach_Report.pdf` (combined, detailed submission report)

## Additional deliverables
- `cynbit_studio_code_insight_source.zip` (runnable Streamlit prototype, source code, tests, requirements and README)
- `Studio_Code_Insight_Opportunity_Report.pdf` (standalone opportunity analysis)
- `Studio_Code_Insight_Technical_Approach.pdf` (standalone technical approach)

## Verification performed
- `pytest -q`: 4 passed.
- No submitted source code is executed by this prototype.

## Important publishing steps
1. Create a new public or reviewer-accessible GitHub repository, e.g. `cynbit-studio-code-insight`.
2. Upload the contents of the ZIP (not the ZIP as the only repository file).
3. Confirm the repository README and run instructions render correctly.
4. Optional: deploy the Streamlit app to Streamlit Community Cloud or another approved host after checking access/privacy settings.
5. Put the combined PDF or a Google Drive share link in the assessment form's Primary Deliverable Link.
6. Add the GitHub repository and optional live demo as additional links.

No GitHub repository, Vercel deployment, Figma file, or Google Drive upload has been created from this environment. Use the generated files to publish them in accounts you control, then paste the real URLs into the assessment portal.
