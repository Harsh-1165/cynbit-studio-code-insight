from __future__ import annotations
import json
import streamlit as st
from evaluator import evaluate_python

st.set_page_config(page_title="Studio Code Insight", page_icon="🧠", layout="wide")
st.title("Studio Code Insight")
st.caption("Explainable AI-assisted code feedback prototype | Python static-analysis baseline")

with st.sidebar:
    st.header("Evaluation scope")
    st.write("Language: Python")
    st.write("Checks: syntax, risky dynamic execution, exception handling, maintainability signals, tests and documentation")
    st.info("This demo does not execute submitted code or send it to an external model.")

task = st.text_area("Challenge / task context (optional)", height=80,
                    placeholder="Example: Return the first non-repeating character in a string.")
code = st.text_area("Paste Python code", height=320,
                    value="""def first_unique(text):
    counts = {}
    for char in text:
        counts[char] = counts.get(char, 0) + 1
    for char in text:
        if counts[char] == 1:
            return char
    return None

assert first_unique('swiss') == 'w'
""")

if st.button("Review code", type="primary", use_container_width=True):
    try:
        result = evaluate_python(code, task)
        c1, c2, c3 = st.columns(3)
        c1.metric("Heuristic score", f"{result.score}/100")
        c2.metric("Readiness", result.level)
        c3.metric("Findings", len(result.findings))
        st.write(result.summary)
        st.subheader("Rubric")
        st.bar_chart(result.rubric)
        left, right = st.columns(2)
        with left:
            st.subheader("Strengths")
            for item in result.strengths:
                st.success(item)
            st.subheader("Next steps")
            for item in result.next_steps:
                st.write(f"- {item}")
        with right:
            st.subheader("Review findings")
            if not result.findings:
                st.success("No configured static-analysis findings detected.")
            for f in result.findings:
                st.warning(f"{f.severity.upper()} | {f.category} | line {f.line or '-'}\n\n{f.message}\n\nWhy it matters: {f.why_it_matters}\n\nSuggested fix: {f.suggested_fix}")
        st.download_button("Download evaluation JSON", json.dumps(result.to_dict(), indent=2),
                           file_name="evaluation.json", mime="application/json")
    except Exception as exc:
        st.error(str(exc))

st.divider()
st.caption("Prototype boundary: AST-based checks are intentionally conservative. Production evaluation should combine sandboxed tests, deterministic static analysis, an LLM explanation layer, and human review.")
