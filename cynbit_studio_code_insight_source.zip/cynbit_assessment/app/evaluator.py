"""Explainable, deterministic baseline for a coding-assessment feedback engine.

This prototype intentionally does not execute submitted code. It combines safe,
static Python AST checks with rubric-based feedback and produces structured JSON.
"""
from __future__ import annotations

import ast
from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class Finding:
    category: str
    severity: str
    line: int | None
    message: str
    why_it_matters: str
    suggested_fix: str


@dataclass
class Evaluation:
    score: int
    level: str
    summary: str
    strengths: list[str]
    findings: list[Finding]
    next_steps: list[str]
    rubric: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        return result


class Analyzer(ast.NodeVisitor):
    def __init__(self) -> None:
        self.findings: list[Finding] = []
        self.functions = 0
        self.docstrings = 0
        self.raises_or_handles = 0

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.functions += 1
        if ast.get_docstring(node):
            self.docstrings += 1
        if len(node.args.args) > 5:
            self.findings.append(Finding(
                "maintainability", "low", node.lineno,
                f"Function '{node.name}' has more than five parameters.",
                "Long parameter lists make call sites harder to understand and maintain.",
                "Group related values into a small data structure or split responsibilities."))
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        self.raises_or_handles += 1
        if node.type is None:
            self.findings.append(Finding(
                "reliability", "high", node.lineno,
                "Bare 'except' catches every exception.",
                "It can hide programming errors and make failures difficult to diagnose.",
                "Catch the expected exception types and handle or re-raise unexpected failures."))
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        name = ""
        if isinstance(node.func, ast.Name):
            name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            name = node.func.attr
        if name == "eval":
            self.findings.append(Finding(
                "security", "critical", getattr(node, "lineno", None),
                "Use of eval() detected.",
                "Evaluating dynamic input as code can create a code-execution vulnerability.",
                "Replace eval with explicit parsing, validation, and a whitelist of allowed operations."))
        if name == "print":
            self.findings.append(Finding(
                "observability", "low", getattr(node, "lineno", None),
                "print() is used for runtime diagnostics.",
                "Unstructured console output is difficult to filter and correlate in deployed services.",
                "Use the logging module with levels and contextual fields in production code."))
        self.generic_visit(node)


def evaluate_python(source: str, task_description: str = "") -> Evaluation:
    if not source.strip():
        raise ValueError("Please provide non-empty Python source code.")
    if len(source) > 50_000:
        raise ValueError("Source exceeds the 50,000 character prototype limit.")

    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        finding = Finding(
            "correctness", "critical", exc.lineno,
            f"Syntax error: {exc.msg}.",
            "The program cannot be parsed, so it cannot run as intended.",
            "Fix the syntax at or near the reported line, then submit again.")
        return Evaluation(0, "Needs revision", "The submission has a syntax error.", [],
                          [finding], ["Resolve the syntax error and rerun tests."],
                          {"correctness": 0, "security": 0, "reliability": 0, "maintainability": 0})

    analyzer = Analyzer()
    analyzer.visit(tree)
    findings = analyzer.findings

    # Prototype rubric: transparent heuristics, not a learned or calibrated model.
    source_lines = [line for line in source.splitlines() if line.strip()]
    has_tests = any(token in source for token in ("assert ", "unittest", "pytest"))
    has_doc = any(isinstance(n, (ast.FunctionDef, ast.ClassDef)) and ast.get_docstring(n)
                  for n in ast.walk(tree))
    has_type_hints = any(isinstance(n, ast.FunctionDef) and
                         (n.returns is not None or any(a.annotation is not None for a in n.args.args))
                         for n in ast.walk(tree))

    critical = sum(f.severity == "critical" for f in findings)
    high = sum(f.severity == "high" for f in findings)
    low = sum(f.severity == "low" for f in findings)

    correctness = 25 if not critical else 8
    security = 25 - (20 if any(f.category == "security" and f.severity == "critical" for f in findings) else 0)
    reliability = max(5, 25 - high * 10 - (5 if not has_tests else 0))
    maintainability = max(5, 25 - low * 3 - (4 if not has_doc else 0) - (2 if not has_type_hints else 0))
    rubric = {"correctness": correctness, "security": security,
              "reliability": reliability, "maintainability": maintainability}
    score = round(sum(rubric.values()) / 100 * 100)

    strengths: list[str] = []
    if has_tests:
        strengths.append("Includes at least one visible test/assertion signal.")
    if has_doc:
        strengths.append("Includes documentation on at least one function or class.")
    if has_type_hints:
        strengths.append("Uses type annotations to communicate intent.")
    if analyzer.functions:
        strengths.append(f"Defines {analyzer.functions} function(s), providing reusable structure.")
    if not strengths:
        strengths.append("The code parses successfully as Python.")

    next_steps = []
    if not has_tests:
        next_steps.append("Add unit tests for normal, boundary, and invalid inputs.")
    if not has_doc:
        next_steps.append("Document public functions with concise docstrings.")
    if not has_type_hints:
        next_steps.append("Add type hints to public function parameters and return values.")
    if findings:
        next_steps.append("Prioritize critical/high-severity findings before style improvements.")
    if not next_steps:
        next_steps.append("Add edge-case tests and validate complexity on larger inputs.")

    level = "Strong" if score >= 85 else "Developing" if score >= 65 else "Needs revision"
    summary = (f"Static review score: {score}/100. This is a heuristic learning aid, "
               "not a correctness proof or a replacement for executing tests.")
    if task_description.strip():
        summary += " Task context was supplied but is not semantically graded by this baseline."
    return Evaluation(score, level, summary, strengths, findings, next_steps, rubric)
