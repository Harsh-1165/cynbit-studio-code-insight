import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from evaluator import evaluate_python


def test_valid_code_and_assertion():
    result = evaluate_python("def add(a: int, b: int) -> int:\n    return a + b\n\nassert add(1, 2) == 3")
    assert result.score > 0
    assert any("test/assertion" in s for s in result.strengths)


def test_eval_is_flagged():
    result = evaluate_python("x = eval(input())")
    assert any(f.category == "security" and f.severity == "critical" for f in result.findings)


def test_syntax_error_is_reported():
    result = evaluate_python("def broken(:\n pass")
    assert result.score == 0
    assert result.findings[0].category == "correctness"


def test_empty_source_rejected():
    try:
        evaluate_python("  ")
        assert False, "Expected ValueError"
    except ValueError:
        pass
